[ansible_core]
param.alert_type = <list> Integration Type. It's a required parameter. It's default value is webhook.
param.environment = <list> Environment. It's a required parameter.
param.send_all_results = <list> Send All Results. It's a required parameter. It's default value is no.
param.results_per_batch = <string> Results per batch.  It's default value is 100.

[ansible_es]
param._cam = <json> Adaptive Response parameters.
param.alert_type = <list> Integration Type. It's a required parameter. It's default value is webhook.
param.environment = <list> Environment. It's a required parameter.
param.send_all_results = <list> Send All Results. It's a required parameter. It's default value is no.
param.results_per_batch = <string> Results per batch.  It's default value is 100.

[ansible_itsi]
param.alert_type = <list> Integration Type. It's a required parameter. It's default value is webhook.
param.environment = <list> Environment. It's a required parameter.
