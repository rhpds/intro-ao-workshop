#
# Copyright 2025 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
REST Schema
"""


from abc import abstractproperty

__all__ = [
    "RestSchemaError",
    "RestSchema",
]


class RestSchemaError(Exception):
    pass


class RestSchema:
    """
    REST Scheme.
    """

    def __init__(self, *args, **kwargs):
        pass

    @staticmethod
    def endpoint_name(name, namespace):
        return f"{namespace}_{name}"

    @abstractproperty
    def product(self):
        pass

    @abstractproperty
    def namespace(self):
        pass

    @abstractproperty
    def version(self):
        pass
